"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.defineRoutes = defineRoutes;
var _configSchema = require("@kbn/config-schema");
var _nodeFetch = _interopRequireDefault(require("node-fetch"));
// Only for Node < 18

function defineRoutes(router, logger, apiKey, mcp_client_url, timeout) {
  /**
   * GET /api/chat_app/search
   * Search conversations by content
   */
  router.get({
    path: '/api/chat_app/search',
    validate: {
      query: _configSchema.schema.object({
        userId: _configSchema.schema.string(),
        searchText: _configSchema.schema.string(),
        space: _configSchema.schema.string(),
        page: _configSchema.schema.maybe(_configSchema.schema.number({
          defaultValue: 0
        })),
        size: _configSchema.schema.maybe(_configSchema.schema.number({
          defaultValue: 10
        }))
      })
    }
  }, async (context, request, response) => {
    try {
      const {
        userId,
        searchText,
        space,
        page,
        size
      } = request.query;
      const backendUrl = `${mcp_client_url}/api/conversations/search?userId=${encodeURIComponent(userId)}&searchText=${encodeURIComponent(searchText)}&space=${encodeURIComponent(space)}&page=${page}&size=${size}`;
      const externalResponse = await (0, _nodeFetch.default)(backendUrl, {
        method: 'GET',
        headers: {
          'x-api-key': apiKey,
          'Content-Type': 'application/json'
        },
        timeout: timeout
      });
      if (!externalResponse.ok) {
        const errorText = await externalResponse.text();
        logger.error(`[chat_app] Search API error: ${errorText}`);
        return response.customError({
          statusCode: externalResponse.status,
          body: `Search API error: ${externalResponse.statusText}`
        });
      }
      const data = await externalResponse.json();
      return response.ok({
        body: data
      });
    } catch (err) {
      logger.error(`[chat_app] Error in search request: ${err}`);
      return response.internalError({
        body: `Server error: ${err.message}`
      });
    }
  });

  /**
   * PUT /api/conversation/name
   * Update conversation name
   */
  router.put({
    path: '/api/conversation/name',
    validate: {
      body: _configSchema.schema.object({
        userId: _configSchema.schema.string(),
        conversationId: _configSchema.schema.string(),
        space: _configSchema.schema.string(),
        name: _configSchema.schema.string({
          minLength: 3,
          maxLength: 100
        })
      })
    }
  }, async (context, request, response) => {
    try {
      const {
        userId,
        conversationId,
        space,
        name
      } = request.body;
      const backendUrl = `${mcp_client_url}/api/conversation/name`;
      const externalResponse = await (0, _nodeFetch.default)(backendUrl, {
        method: 'PUT',
        headers: {
          'x-api-key': apiKey,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId,
          conversationId,
          space,
          name
        }),
        timeout: timeout
      });
      if (!externalResponse.ok) {
        const errorText = await externalResponse.text();
        logger.error(`[chat_app] Update name API error: ${errorText}`);
        return response.customError({
          statusCode: externalResponse.status,
          body: `Update name API error: ${externalResponse.statusText}`
        });
      }
      const data = await externalResponse.json();
      return response.ok({
        body: data
      });
    } catch (err) {
      logger.error(`[chat_app] Error updating conversation name: ${err}`);
      return response.internalError({
        body: `Server error: ${err.message}`
      });
    }
  });

  /**
   * POST /api/chat_app/feedback
   * Submit user feedback for AI responses
   */
  router.post({
    path: '/api/chat_app/feedback',
    validate: {
      body: _configSchema.schema.object({
        conversationId: _configSchema.schema.string(),
        space: _configSchema.schema.string(),
        user: _configSchema.schema.object({
          userId: _configSchema.schema.string()
        }),
        context: _configSchema.schema.object({
          prompt: _configSchema.schema.string(),
          llmResponse: _configSchema.schema.string()
        }),
        feedback: _configSchema.schema.object({
          simpleRating: _configSchema.schema.oneOf([_configSchema.schema.literal('UP'), _configSchema.schema.literal('DOWN')]),
          comment: _configSchema.schema.maybe(_configSchema.schema.string())
        })
      })
    }
  }, async (context, request, response) => {
    try {
      const feedbackData = request.body;
      const backendUrl = `${mcp_client_url}/api/feedback`;
      const externalResponse = await (0, _nodeFetch.default)(backendUrl, {
        method: 'POST',
        headers: {
          'x-api-key': apiKey,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(feedbackData)
      });
      if (!externalResponse.ok) {
        const errorText = await externalResponse.text();
        logger.error(`[chat_app] Backend error response: ${errorText}`);
        return response.customError({
          statusCode: externalResponse.status,
          body: `Feedback API error: ${externalResponse.statusText}`
        });
      }
      const data = await externalResponse.json();
      return response.ok({
        body: data
      });
    } catch (err) {
      logger.error(`[chat_app] Error submitting feedback: ${err}`);
      logger.error(`[chat_app] Error stack: ${err.stack}`);
      return response.internalError({
        body: `Server error: ${err.message}`
      });
    }
  });
  /**
   * GET /api/chat_app/config
   * Returns plugin configuration
   */
  router.get({
    path: '/api/chat_app/config',
    validate: false
  }, async (context, request, response) => {
    return response.ok({
      body: {
        timeout
      }
    });
  });

  /**
   * GET /api/chat_app/user_chat_summary
   * Fetches a summary of user chats from external API
   */
  router.get({
    path: '/api/chat_app/user_chat_summary',
    validate: {
      query: _configSchema.schema.object({
        userId: _configSchema.schema.string(),
        lastReadTimestamp: _configSchema.schema.maybe(_configSchema.schema.string()),
        spaceId: _configSchema.schema.maybe(_configSchema.schema.string())
      }, {
        unknowns: 'ignore'
      })
    }
  }, async (context, request, response) => {
    const {
      userId,
      lastReadTimestamp,
      spaceId
    } = request.query;
    let backendUrl = `${mcp_client_url}/api/user-chat-summary?userId=${encodeURIComponent(userId)}`;
    if (lastReadTimestamp) {
      backendUrl += `&lastReadTimestamp=${encodeURIComponent(lastReadTimestamp)}`;
    }
    if (spaceId) {
      backendUrl += `&space=${encodeURIComponent(spaceId)}`;
    }
    try {
      const externalResponse = await (0, _nodeFetch.default)(backendUrl, {
        method: 'GET',
        headers: {
          'x-api-key': apiKey,
          'Content-Type': 'application/json'
        },
        timeout: timeout // Configurable timeout from kibana.yml
      });
      if (!externalResponse.ok) {
        return response.customError({
          statusCode: externalResponse.status,
          body: `External API error: ${externalResponse.statusText}`
        });
      }
      const data = await externalResponse.json();
      return response.ok({
        body: data
      });
    } catch (err) {
      logger.error(`[tower_chat] Error fetching chat summary: ${err}`);
      return response.internalError({
        body: `Server error: ${err}`
      });
    }
  });

  /**
   * GET /api/chat_app/user_chat_details
   * Returns detailed conversation history for a user
   */
  router.get({
    path: '/api/chat_app/user_chat_details',
    validate: {
      query: _configSchema.schema.object({
        conversationId: _configSchema.schema.string(),
        userId: _configSchema.schema.string(),
        lastReadTimestamp: _configSchema.schema.maybe(_configSchema.schema.string()),
        spaceId: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, request, response) => {
    const {
      conversationId,
      userId,
      lastReadTimestamp,
      spaceId
    } = request.query;
    let backendUrl = `${mcp_client_url}/api/user-chat-details?conversationId=${encodeURIComponent(conversationId)}&userId=${encodeURIComponent(userId)}`;
    if (lastReadTimestamp) {
      backendUrl += `&lastReadTimestamp=${encodeURIComponent(lastReadTimestamp)}`;
    }
    if (spaceId) {
      backendUrl += `&space=${encodeURIComponent(spaceId)}`;
    }
    try {
      const externalResponse = await (0, _nodeFetch.default)(backendUrl, {
        method: 'GET',
        headers: {
          'x-api-key': apiKey,
          'Content-Type': 'application/json'
        },
        timeout: timeout // Configurable timeout from kibana.yml
      });
      if (!externalResponse.ok) {
        return response.customError({
          statusCode: externalResponse.status,
          body: `External API error: ${externalResponse.statusText}`
        });
      }
      const data = await externalResponse.json();
      return response.ok({
        body: data
      });
    } catch (err) {
      logger.error(`[tower_chat] Error fetching chat details: ${err}`);
      return response.internalError({
        body: `Server error: ${err}`
      });
    }
  });

  /**
   * GET /api/chat_app/chat
   * Sends a chat input and returns AI response
   */
  router.get({
    path: '/api/chat_app/chat',
    validate: {
      query: _configSchema.schema.object({
        userId: _configSchema.schema.string(),
        input: _configSchema.schema.string(),
        conversationId: _configSchema.schema.string(),
        spaceId: _configSchema.schema.maybe(_configSchema.schema.string()),
        agentId: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, request, response) => {
    try {
      const {
        userId,
        input,
        conversationId,
        spaceId,
        agentId
      } = request.query;
      let backendUrl = `${mcp_client_url}/api/chat?userId=${encodeURIComponent(userId)}&input=${encodeURIComponent(input)}&conversationId=${encodeURIComponent(conversationId)}&space=${encodeURIComponent(spaceId)}`;
      if (agentId) {
        backendUrl += `&agentId=${encodeURIComponent(agentId)}`;
      }
      const externalResponse = await (0, _nodeFetch.default)(backendUrl, {
        method: 'POST',
        headers: {
          'x-api-key': apiKey,
          'Content-Type': 'application/json'
        },
        timeout: timeout // Configurable timeout from kibana.yml
      });
      if (!externalResponse.ok) {
        logger.error(`[tower_chat] External API error: ${externalResponse.status} ${externalResponse.statusText}`);
        return response.customError({
          statusCode: externalResponse.status,
          body: `External API error: ${externalResponse.statusText}`
        });
      }
      const data = await externalResponse.json();
      return response.ok({
        body: data
      });
    } catch (err) {
      logger.error(`[tower_chat] Error in chat request: ${err}`);
      return response.internalError({
        body: `Server error: ${err}`
      });
    }
  });

  /**
   * GET /api/chat_app/search-agents
   * Search for available agents based on space and code name pattern
   */
  router.get({
    path: '/api/chat_app/search-agents',
    validate: {
      query: _configSchema.schema.object({
        space: _configSchema.schema.string(),
        codeNameLike: _configSchema.schema.string({
          minLength: 4
        }),
        size: _configSchema.schema.maybe(_configSchema.schema.number({
          defaultValue: 12
        })),
        pageNo: _configSchema.schema.maybe(_configSchema.schema.number({
          defaultValue: 0
        }))
      })
    }
  }, async (context, request, response) => {
    try {
      const {
        space,
        codeNameLike,
        size,
        pageNo
      } = request.query;
      let backendUrl = `${mcp_client_url}/api/search-agents?space=${encodeURIComponent(space)}&codeNameLike=${encodeURIComponent(codeNameLike)}&size=${encodeURIComponent(size || 12)}&pageNo=${encodeURIComponent(pageNo || 0)}`;
      const externalResponse = await (0, _nodeFetch.default)(backendUrl, {
        method: 'GET',
        headers: {
          'x-api-key': apiKey,
          'Content-Type': 'application/json'
        },
        timeout: timeout
      });
      if (!externalResponse.ok) {
        const errorText = await externalResponse.text();
        logger.error(`[chat_app] Search agents API error: ${errorText}`);
        return response.customError({
          statusCode: externalResponse.status,
          body: `Search agents API error: ${externalResponse.statusText}`
        });
      }
      const data = await externalResponse.json();
      return response.ok({
        body: data
      });
    } catch (err) {
      logger.error(`[chat_app] Error in search agents request: ${err}`);
      return response.internalError({
        body: `Server error: ${err.message}`
      });
    }
  });

  /**
   * GET /api/chat_app/list-agents
   * List all available agents for a space
   */
  router.get({
    path: '/api/chat_app/list-agents',
    validate: {
      query: _configSchema.schema.object({
        space: _configSchema.schema.string(),
        addAgentInfo: _configSchema.schema.maybe(_configSchema.schema.boolean({
          defaultValue: false
        })),
        size: _configSchema.schema.maybe(_configSchema.schema.number({
          defaultValue: 12
        })),
        pageNo: _configSchema.schema.maybe(_configSchema.schema.number({
          defaultValue: 0
        }))
      })
    }
  }, async (context, request, response) => {
    try {
      const {
        space,
        addAgentInfo,
        size,
        pageNo
      } = request.query;
      let backendUrl = `${mcp_client_url}/api/list-agents?space=${encodeURIComponent(space)}&size=${encodeURIComponent(size || 12)}&pageNo=${encodeURIComponent(pageNo || 0)}`;
      if (addAgentInfo) {
        backendUrl += `&addAgentInfo=${encodeURIComponent(addAgentInfo)}`;
      }
      const externalResponse = await (0, _nodeFetch.default)(backendUrl, {
        method: 'GET',
        headers: {
          'x-api-key': apiKey,
          'Content-Type': 'application/json'
        },
        timeout: timeout
      });
      if (!externalResponse.ok) {
        const errorText = await externalResponse.text();
        logger.error(`[chat_app] List agents API error: ${errorText}`);
        return response.customError({
          statusCode: externalResponse.status,
          body: `List agents API error: ${externalResponse.statusText}`
        });
      }
      const data = await externalResponse.json();
      return response.ok({
        body: data
      });
    } catch (err) {
      logger.error(`[chat_app] Error in list agents request: ${err}`);
      return response.internalError({
        body: `Server error: ${err.message}`
      });
    }
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnU2NoZW1hIiwicmVxdWlyZSIsIl9ub2RlRmV0Y2giLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiZGVmaW5lUm91dGVzIiwicm91dGVyIiwibG9nZ2VyIiwiYXBpS2V5IiwibWNwX2NsaWVudF91cmwiLCJ0aW1lb3V0IiwiZ2V0IiwicGF0aCIsInZhbGlkYXRlIiwicXVlcnkiLCJzY2hlbWEiLCJvYmplY3QiLCJ1c2VySWQiLCJzdHJpbmciLCJzZWFyY2hUZXh0Iiwic3BhY2UiLCJwYWdlIiwibWF5YmUiLCJudW1iZXIiLCJkZWZhdWx0VmFsdWUiLCJzaXplIiwiY29udGV4dCIsInJlcXVlc3QiLCJyZXNwb25zZSIsImJhY2tlbmRVcmwiLCJlbmNvZGVVUklDb21wb25lbnQiLCJleHRlcm5hbFJlc3BvbnNlIiwiZmV0Y2giLCJtZXRob2QiLCJoZWFkZXJzIiwib2siLCJlcnJvclRleHQiLCJ0ZXh0IiwiZXJyb3IiLCJjdXN0b21FcnJvciIsInN0YXR1c0NvZGUiLCJzdGF0dXMiLCJib2R5Iiwic3RhdHVzVGV4dCIsImRhdGEiLCJqc29uIiwiZXJyIiwiaW50ZXJuYWxFcnJvciIsIm1lc3NhZ2UiLCJwdXQiLCJjb252ZXJzYXRpb25JZCIsIm5hbWUiLCJtaW5MZW5ndGgiLCJtYXhMZW5ndGgiLCJKU09OIiwic3RyaW5naWZ5IiwicG9zdCIsInVzZXIiLCJwcm9tcHQiLCJsbG1SZXNwb25zZSIsImZlZWRiYWNrIiwic2ltcGxlUmF0aW5nIiwib25lT2YiLCJsaXRlcmFsIiwiY29tbWVudCIsImZlZWRiYWNrRGF0YSIsInN0YWNrIiwibGFzdFJlYWRUaW1lc3RhbXAiLCJzcGFjZUlkIiwidW5rbm93bnMiLCJpbnB1dCIsImFnZW50SWQiLCJjb2RlTmFtZUxpa2UiLCJwYWdlTm8iLCJhZGRBZ2VudEluZm8iLCJib29sZWFuIl0sInNvdXJjZXMiOlsiaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc2NoZW1hIH0gZnJvbSAnQGtibi9jb25maWctc2NoZW1hJztcbmltcG9ydCB0eXBlIHsgSVJvdXRlciwgTG9nZ2VyIH0gZnJvbSAnQGtibi9jb3JlL3NlcnZlcic7XG5pbXBvcnQgZmV0Y2ggZnJvbSAnbm9kZS1mZXRjaCc7IC8vIE9ubHkgZm9yIE5vZGUgPCAxOFxuXG5cbmV4cG9ydCBmdW5jdGlvbiBkZWZpbmVSb3V0ZXMocm91dGVyOiBJUm91dGVyLCBsb2dnZXI6IExvZ2dlciwgYXBpS2V5OiBzdHJpbmcsIG1jcF9jbGllbnRfdXJsOiBzdHJpbmcsIHRpbWVvdXQ6IG51bWJlcikge1xuICAvKipcbiAgICogR0VUIC9hcGkvY2hhdF9hcHAvc2VhcmNoXG4gICAqIFNlYXJjaCBjb252ZXJzYXRpb25zIGJ5IGNvbnRlbnRcbiAgICovXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvY2hhdF9hcHAvc2VhcmNoJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICB1c2VySWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICBzZWFyY2hUZXh0OiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgc3BhY2U6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICBwYWdlOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcih7IGRlZmF1bHRWYWx1ZTogMCB9KSksXG4gICAgICAgICAgc2l6ZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoeyBkZWZhdWx0VmFsdWU6IDEwIH0pKVxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHsgdXNlcklkLCBzZWFyY2hUZXh0LCBzcGFjZSwgcGFnZSwgc2l6ZSB9ID0gcmVxdWVzdC5xdWVyeTtcbiAgICAgICAgY29uc3QgYmFja2VuZFVybCA9IGAke21jcF9jbGllbnRfdXJsfS9hcGkvY29udmVyc2F0aW9ucy9zZWFyY2g/dXNlcklkPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHVzZXJJZCl9JnNlYXJjaFRleHQ9JHtlbmNvZGVVUklDb21wb25lbnQoc2VhcmNoVGV4dCl9JnNwYWNlPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHNwYWNlKX0mcGFnZT0ke3BhZ2V9JnNpemU9JHtzaXplfWA7XG5cbiAgICAgICAgY29uc3QgZXh0ZXJuYWxSZXNwb25zZSA9IGF3YWl0IGZldGNoKGJhY2tlbmRVcmwsIHtcbiAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICd4LWFwaS1rZXknOiBhcGlLZXksXG4gICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgdGltZW91dDogdGltZW91dCxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKCFleHRlcm5hbFJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgY29uc3QgZXJyb3JUZXh0ID0gYXdhaXQgZXh0ZXJuYWxSZXNwb25zZS50ZXh0KCk7XG4gICAgICAgICAgbG9nZ2VyLmVycm9yKGBbY2hhdF9hcHBdIFNlYXJjaCBBUEkgZXJyb3I6ICR7ZXJyb3JUZXh0fWApO1xuICAgICAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b21FcnJvcih7XG4gICAgICAgICAgICBzdGF0dXNDb2RlOiBleHRlcm5hbFJlc3BvbnNlLnN0YXR1cyxcbiAgICAgICAgICAgIGJvZHk6IGBTZWFyY2ggQVBJIGVycm9yOiAke2V4dGVybmFsUmVzcG9uc2Uuc3RhdHVzVGV4dH1gLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGV4dGVybmFsUmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiBkYXRhIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGxvZ2dlci5lcnJvcihgW2NoYXRfYXBwXSBFcnJvciBpbiBzZWFyY2ggcmVxdWVzdDogJHtlcnJ9YCk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5pbnRlcm5hbEVycm9yKHsgYm9keTogYFNlcnZlciBlcnJvcjogJHtlcnIubWVzc2FnZX1gIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvKipcbiAgICogUFVUIC9hcGkvY29udmVyc2F0aW9uL25hbWVcbiAgICogVXBkYXRlIGNvbnZlcnNhdGlvbiBuYW1lXG4gICAqL1xuICByb3V0ZXIucHV0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2NvbnZlcnNhdGlvbi9uYW1lJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIGJvZHk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHVzZXJJZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIGNvbnZlcnNhdGlvbklkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgc3BhY2U6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICBuYW1lOiBzY2hlbWEuc3RyaW5nKHsgbWluTGVuZ3RoOiAzLCBtYXhMZW5ndGg6IDEwMCB9KSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB7IHVzZXJJZCwgY29udmVyc2F0aW9uSWQsIHNwYWNlLCBuYW1lIH0gPSByZXF1ZXN0LmJvZHk7XG4gICAgICAgIGNvbnN0IGJhY2tlbmRVcmwgPSBgJHttY3BfY2xpZW50X3VybH0vYXBpL2NvbnZlcnNhdGlvbi9uYW1lYDtcbiAgICAgICAgXG4gICAgICAgIGNvbnN0IGV4dGVybmFsUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChiYWNrZW5kVXJsLCB7XG4gICAgICAgICAgbWV0aG9kOiAnUFVUJyxcbiAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAneC1hcGkta2V5JzogYXBpS2V5LFxuICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgdXNlcklkLCBjb252ZXJzYXRpb25JZCwgc3BhY2UsIG5hbWUgfSksXG4gICAgICAgICAgdGltZW91dDogdGltZW91dCxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKCFleHRlcm5hbFJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgY29uc3QgZXJyb3JUZXh0ID0gYXdhaXQgZXh0ZXJuYWxSZXNwb25zZS50ZXh0KCk7XG4gICAgICAgICAgbG9nZ2VyLmVycm9yKGBbY2hhdF9hcHBdIFVwZGF0ZSBuYW1lIEFQSSBlcnJvcjogJHtlcnJvclRleHR9YCk7XG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IGV4dGVybmFsUmVzcG9uc2Uuc3RhdHVzLFxuICAgICAgICAgICAgYm9keTogYFVwZGF0ZSBuYW1lIEFQSSBlcnJvcjogJHtleHRlcm5hbFJlc3BvbnNlLnN0YXR1c1RleHR9YCxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBleHRlcm5hbFJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogZGF0YSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBsb2dnZXIuZXJyb3IoYFtjaGF0X2FwcF0gRXJyb3IgdXBkYXRpbmcgY29udmVyc2F0aW9uIG5hbWU6ICR7ZXJyfWApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuaW50ZXJuYWxFcnJvcih7IGJvZHk6IGBTZXJ2ZXIgZXJyb3I6ICR7ZXJyLm1lc3NhZ2V9YCB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgLyoqXG4gICAqIFBPU1QgL2FwaS9jaGF0X2FwcC9mZWVkYmFja1xuICAgKiBTdWJtaXQgdXNlciBmZWVkYmFjayBmb3IgQUkgcmVzcG9uc2VzXG4gICAqL1xuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9jaGF0X2FwcC9mZWVkYmFjaycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBjb252ZXJzYXRpb25JZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIHNwYWNlOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgdXNlcjogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgICB1c2VySWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICB9KSxcbiAgICAgICAgICBjb250ZXh0OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICAgIHByb21wdDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgICAgbGxtUmVzcG9uc2U6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICB9KSxcbiAgICAgICAgICBmZWVkYmFjazogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgICBzaW1wbGVSYXRpbmc6IHNjaGVtYS5vbmVPZihbc2NoZW1hLmxpdGVyYWwoJ1VQJyksIHNjaGVtYS5saXRlcmFsKCdET1dOJyldKSxcbiAgICAgICAgICAgIGNvbW1lbnQ6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIH0pLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGZlZWRiYWNrRGF0YSA9IHJlcXVlc3QuYm9keTtcbiAgICAgICAgY29uc3QgYmFja2VuZFVybCA9IGAke21jcF9jbGllbnRfdXJsfS9hcGkvZmVlZGJhY2tgO1xuICAgICAgICBjb25zdCBleHRlcm5hbFJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYmFja2VuZFVybCwge1xuICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICd4LWFwaS1rZXknOiBhcGlLZXksXG4gICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoZmVlZGJhY2tEYXRhKSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKCFleHRlcm5hbFJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgY29uc3QgZXJyb3JUZXh0ID0gYXdhaXQgZXh0ZXJuYWxSZXNwb25zZS50ZXh0KCk7XG4gICAgICAgICAgbG9nZ2VyLmVycm9yKGBbY2hhdF9hcHBdIEJhY2tlbmQgZXJyb3IgcmVzcG9uc2U6ICR7ZXJyb3JUZXh0fWApO1xuICAgICAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b21FcnJvcih7XG4gICAgICAgICAgICBzdGF0dXNDb2RlOiBleHRlcm5hbFJlc3BvbnNlLnN0YXR1cyxcbiAgICAgICAgICAgIGJvZHk6IGBGZWVkYmFjayBBUEkgZXJyb3I6ICR7ZXh0ZXJuYWxSZXNwb25zZS5zdGF0dXNUZXh0fWAsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgZXh0ZXJuYWxSZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IGRhdGEgfSk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgbG9nZ2VyLmVycm9yKGBbY2hhdF9hcHBdIEVycm9yIHN1Ym1pdHRpbmcgZmVlZGJhY2s6ICR7ZXJyfWApO1xuICAgICAgICBsb2dnZXIuZXJyb3IoYFtjaGF0X2FwcF0gRXJyb3Igc3RhY2s6ICR7ZXJyLnN0YWNrfWApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuaW50ZXJuYWxFcnJvcih7IGJvZHk6IGBTZXJ2ZXIgZXJyb3I6ICR7ZXJyLm1lc3NhZ2V9YCB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG4gIC8qKlxuICAgKiBHRVQgL2FwaS9jaGF0X2FwcC9jb25maWdcbiAgICogUmV0dXJucyBwbHVnaW4gY29uZmlndXJhdGlvblxuICAgKi9cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9jaGF0X2FwcC9jb25maWcnLFxuICAgICAgdmFsaWRhdGU6IGZhbHNlLFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBcbiAgICAgICAgYm9keTogeyBcbiAgICAgICAgICB0aW1lb3V0IFxuICAgICAgICB9IFxuICAgICAgfSk7XG4gICAgfVxuICApO1xuXG4gIC8qKlxuICAgKiBHRVQgL2FwaS9jaGF0X2FwcC91c2VyX2NoYXRfc3VtbWFyeVxuICAgKiBGZXRjaGVzIGEgc3VtbWFyeSBvZiB1c2VyIGNoYXRzIGZyb20gZXh0ZXJuYWwgQVBJXG4gICAqL1xuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2NoYXRfYXBwL3VzZXJfY2hhdF9zdW1tYXJ5JyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICB1c2VySWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICBsYXN0UmVhZFRpbWVzdGFtcDogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgc3BhY2VJZDogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSlcbiAgICAgICAgfSwgeyB1bmtub3duczogJ2lnbm9yZScgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICBjb25zdCB7IHVzZXJJZCwgbGFzdFJlYWRUaW1lc3RhbXAsIHNwYWNlSWQgfSA9IHJlcXVlc3QucXVlcnk7XG4gICAgICBcbiAgICAgIGxldCBiYWNrZW5kVXJsID0gYCR7bWNwX2NsaWVudF91cmx9L2FwaS91c2VyLWNoYXQtc3VtbWFyeT91c2VySWQ9JHtlbmNvZGVVUklDb21wb25lbnQodXNlcklkKX1gO1xuICAgICAgaWYgKGxhc3RSZWFkVGltZXN0YW1wKSB7XG4gICAgICAgIGJhY2tlbmRVcmwgKz0gYCZsYXN0UmVhZFRpbWVzdGFtcD0ke2VuY29kZVVSSUNvbXBvbmVudChsYXN0UmVhZFRpbWVzdGFtcCl9YDtcbiAgICAgIH1cbiAgICAgIGlmIChzcGFjZUlkKSB7XG4gICAgICAgIGJhY2tlbmRVcmwgKz0gYCZzcGFjZT0ke2VuY29kZVVSSUNvbXBvbmVudChzcGFjZUlkKX1gO1xuICAgICAgfVxuXG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBleHRlcm5hbFJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYmFja2VuZFVybCwge1xuICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgJ3gtYXBpLWtleSc6IGFwaUtleSxcbiAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB0aW1lb3V0OiB0aW1lb3V0LCAvLyBDb25maWd1cmFibGUgdGltZW91dCBmcm9tIGtpYmFuYS55bWxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKCFleHRlcm5hbFJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IGV4dGVybmFsUmVzcG9uc2Uuc3RhdHVzLFxuICAgICAgICAgICAgYm9keTogYEV4dGVybmFsIEFQSSBlcnJvcjogJHtleHRlcm5hbFJlc3BvbnNlLnN0YXR1c1RleHR9YCxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBleHRlcm5hbFJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogZGF0YSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBsb2dnZXIuZXJyb3IoYFt0b3dlcl9jaGF0XSBFcnJvciBmZXRjaGluZyBjaGF0IHN1bW1hcnk6ICR7ZXJyfWApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuaW50ZXJuYWxFcnJvcih7IGJvZHk6IGBTZXJ2ZXIgZXJyb3I6ICR7ZXJyfWAgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIC8qKlxuICAgKiBHRVQgL2FwaS9jaGF0X2FwcC91c2VyX2NoYXRfZGV0YWlsc1xuICAgKiBSZXR1cm5zIGRldGFpbGVkIGNvbnZlcnNhdGlvbiBoaXN0b3J5IGZvciBhIHVzZXJcbiAgICovXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvY2hhdF9hcHAvdXNlcl9jaGF0X2RldGFpbHMnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcXVlcnk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGNvbnZlcnNhdGlvbklkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgdXNlcklkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgbGFzdFJlYWRUaW1lc3RhbXA6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIHNwYWNlSWQ6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgY29uc3QgeyBjb252ZXJzYXRpb25JZCwgdXNlcklkLCBsYXN0UmVhZFRpbWVzdGFtcCwgc3BhY2VJZCB9ID0gcmVxdWVzdC5xdWVyeTtcblxuICAgICAgbGV0IGJhY2tlbmRVcmwgPSBgJHttY3BfY2xpZW50X3VybH0vYXBpL3VzZXItY2hhdC1kZXRhaWxzP2NvbnZlcnNhdGlvbklkPSR7ZW5jb2RlVVJJQ29tcG9uZW50KGNvbnZlcnNhdGlvbklkKX0mdXNlcklkPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHVzZXJJZCl9YDtcbiAgICAgIGlmIChsYXN0UmVhZFRpbWVzdGFtcCkge1xuICAgICAgICBiYWNrZW5kVXJsICs9IGAmbGFzdFJlYWRUaW1lc3RhbXA9JHtlbmNvZGVVUklDb21wb25lbnQobGFzdFJlYWRUaW1lc3RhbXApfWA7XG4gICAgICB9XG4gICAgICBpZiAoc3BhY2VJZCkge1xuICAgICAgICBiYWNrZW5kVXJsICs9IGAmc3BhY2U9JHtlbmNvZGVVUklDb21wb25lbnQoc3BhY2VJZCl9YDtcbiAgICAgIH1cblxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgZXh0ZXJuYWxSZXNwb25zZSA9IGF3YWl0IGZldGNoKGJhY2tlbmRVcmwsIHtcbiAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICd4LWFwaS1rZXknOiBhcGlLZXksXG4gICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgdGltZW91dDogdGltZW91dCwgLy8gQ29uZmlndXJhYmxlIHRpbWVvdXQgZnJvbSBraWJhbmEueW1sXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGlmICghZXh0ZXJuYWxSZXNwb25zZS5vaykge1xuICAgICAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b21FcnJvcih7XG4gICAgICAgICAgICBzdGF0dXNDb2RlOiBleHRlcm5hbFJlc3BvbnNlLnN0YXR1cyxcbiAgICAgICAgICAgIGJvZHk6IGBFeHRlcm5hbCBBUEkgZXJyb3I6ICR7ZXh0ZXJuYWxSZXNwb25zZS5zdGF0dXNUZXh0fWAsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgZXh0ZXJuYWxSZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IGRhdGEgfSk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgbG9nZ2VyLmVycm9yKGBbdG93ZXJfY2hhdF0gRXJyb3IgZmV0Y2hpbmcgY2hhdCBkZXRhaWxzOiAke2Vycn1gKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmludGVybmFsRXJyb3IoeyBib2R5OiBgU2VydmVyIGVycm9yOiAke2Vycn1gIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvKipcbiAgICogR0VUIC9hcGkvY2hhdF9hcHAvY2hhdFxuICAgKiBTZW5kcyBhIGNoYXQgaW5wdXQgYW5kIHJldHVybnMgQUkgcmVzcG9uc2VcbiAgICovXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvY2hhdF9hcHAvY2hhdCcsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBxdWVyeTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgdXNlcklkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgaW5wdXQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICBjb252ZXJzYXRpb25JZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIHNwYWNlSWQ6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIGFnZW50SWQ6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgeyB1c2VySWQsIGlucHV0LCBjb252ZXJzYXRpb25JZCwgc3BhY2VJZCwgYWdlbnRJZCB9ID0gcmVxdWVzdC5xdWVyeTtcbiAgICAgICAgbGV0IGJhY2tlbmRVcmwgPSBgJHttY3BfY2xpZW50X3VybH0vYXBpL2NoYXQ/dXNlcklkPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHVzZXJJZCl9JmlucHV0PSR7ZW5jb2RlVVJJQ29tcG9uZW50KGlucHV0KX0mY29udmVyc2F0aW9uSWQ9JHtlbmNvZGVVUklDb21wb25lbnQoY29udmVyc2F0aW9uSWQpfSZzcGFjZT0ke2VuY29kZVVSSUNvbXBvbmVudChzcGFjZUlkKX1gO1xuICAgICAgICBcbiAgICAgICAgaWYgKGFnZW50SWQpIHtcbiAgICAgICAgICBiYWNrZW5kVXJsICs9IGAmYWdlbnRJZD0ke2VuY29kZVVSSUNvbXBvbmVudChhZ2VudElkKX1gO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgZXh0ZXJuYWxSZXNwb25zZSA9IGF3YWl0IGZldGNoKGJhY2tlbmRVcmwsIHtcbiAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAneC1hcGkta2V5JzogYXBpS2V5LFxuICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHRpbWVvdXQ6IHRpbWVvdXQsIC8vIENvbmZpZ3VyYWJsZSB0aW1lb3V0IGZyb20ga2liYW5hLnltbFxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAoIWV4dGVybmFsUmVzcG9uc2Uub2spIHtcbiAgICAgICAgICBsb2dnZXIuZXJyb3IoYFt0b3dlcl9jaGF0XSBFeHRlcm5hbCBBUEkgZXJyb3I6ICR7ZXh0ZXJuYWxSZXNwb25zZS5zdGF0dXN9ICR7ZXh0ZXJuYWxSZXNwb25zZS5zdGF0dXNUZXh0fWApO1xuICAgICAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b21FcnJvcih7XG4gICAgICAgICAgICBzdGF0dXNDb2RlOiBleHRlcm5hbFJlc3BvbnNlLnN0YXR1cyxcbiAgICAgICAgICAgIGJvZHk6IGBFeHRlcm5hbCBBUEkgZXJyb3I6ICR7ZXh0ZXJuYWxSZXNwb25zZS5zdGF0dXNUZXh0fWAsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgZXh0ZXJuYWxSZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IGRhdGEgfSk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgbG9nZ2VyLmVycm9yKGBbdG93ZXJfY2hhdF0gRXJyb3IgaW4gY2hhdCByZXF1ZXN0OiAke2Vycn1gKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmludGVybmFsRXJyb3IoeyBib2R5OiBgU2VydmVyIGVycm9yOiAke2Vycn1gIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvKipcbiAgICogR0VUIC9hcGkvY2hhdF9hcHAvc2VhcmNoLWFnZW50c1xuICAgKiBTZWFyY2ggZm9yIGF2YWlsYWJsZSBhZ2VudHMgYmFzZWQgb24gc3BhY2UgYW5kIGNvZGUgbmFtZSBwYXR0ZXJuXG4gICAqL1xuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2NoYXRfYXBwL3NlYXJjaC1hZ2VudHMnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcXVlcnk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHNwYWNlOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgY29kZU5hbWVMaWtlOiBzY2hlbWEuc3RyaW5nKHsgbWluTGVuZ3RoOiA0IH0pLFxuICAgICAgICAgIHNpemU6IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKHsgZGVmYXVsdFZhbHVlOiAxMiB9KSksXG4gICAgICAgICAgcGFnZU5vOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcih7IGRlZmF1bHRWYWx1ZTogMCB9KSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgeyBzcGFjZSwgY29kZU5hbWVMaWtlLCBzaXplLCBwYWdlTm8gfSA9IHJlcXVlc3QucXVlcnk7XG4gICAgICAgIGxldCBiYWNrZW5kVXJsID0gYCR7bWNwX2NsaWVudF91cmx9L2FwaS9zZWFyY2gtYWdlbnRzP3NwYWNlPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHNwYWNlKX0mY29kZU5hbWVMaWtlPSR7ZW5jb2RlVVJJQ29tcG9uZW50KGNvZGVOYW1lTGlrZSl9JnNpemU9JHtlbmNvZGVVUklDb21wb25lbnQoc2l6ZSB8fCAxMil9JnBhZ2VObz0ke2VuY29kZVVSSUNvbXBvbmVudChwYWdlTm8gfHwgMCl9YDtcblxuICAgICAgICBjb25zdCBleHRlcm5hbFJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYmFja2VuZFVybCwge1xuICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgJ3gtYXBpLWtleSc6IGFwaUtleSxcbiAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB0aW1lb3V0OiB0aW1lb3V0LFxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAoIWV4dGVybmFsUmVzcG9uc2Uub2spIHtcbiAgICAgICAgICBjb25zdCBlcnJvclRleHQgPSBhd2FpdCBleHRlcm5hbFJlc3BvbnNlLnRleHQoKTtcbiAgICAgICAgICBsb2dnZXIuZXJyb3IoYFtjaGF0X2FwcF0gU2VhcmNoIGFnZW50cyBBUEkgZXJyb3I6ICR7ZXJyb3JUZXh0fWApO1xuICAgICAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b21FcnJvcih7XG4gICAgICAgICAgICBzdGF0dXNDb2RlOiBleHRlcm5hbFJlc3BvbnNlLnN0YXR1cyxcbiAgICAgICAgICAgIGJvZHk6IGBTZWFyY2ggYWdlbnRzIEFQSSBlcnJvcjogJHtleHRlcm5hbFJlc3BvbnNlLnN0YXR1c1RleHR9YCxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBleHRlcm5hbFJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogZGF0YSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBsb2dnZXIuZXJyb3IoYFtjaGF0X2FwcF0gRXJyb3IgaW4gc2VhcmNoIGFnZW50cyByZXF1ZXN0OiAke2Vycn1gKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmludGVybmFsRXJyb3IoeyBib2R5OiBgU2VydmVyIGVycm9yOiAke2Vyci5tZXNzYWdlfWAgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIC8qKlxuICAgKiBHRVQgL2FwaS9jaGF0X2FwcC9saXN0LWFnZW50c1xuICAgKiBMaXN0IGFsbCBhdmFpbGFibGUgYWdlbnRzIGZvciBhIHNwYWNlXG4gICAqL1xuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2NoYXRfYXBwL2xpc3QtYWdlbnRzJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBzcGFjZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIGFkZEFnZW50SW5mbzogc2NoZW1hLm1heWJlKHNjaGVtYS5ib29sZWFuKHsgZGVmYXVsdFZhbHVlOiBmYWxzZSB9KSksXG4gICAgICAgICAgc2l6ZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoeyBkZWZhdWx0VmFsdWU6IDEyIH0pKSxcbiAgICAgICAgICBwYWdlTm86IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKHsgZGVmYXVsdFZhbHVlOiAwIH0pKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB7IHNwYWNlLCBhZGRBZ2VudEluZm8sIHNpemUsIHBhZ2VObyB9ID0gcmVxdWVzdC5xdWVyeTtcbiAgICAgICAgbGV0IGJhY2tlbmRVcmwgPSBgJHttY3BfY2xpZW50X3VybH0vYXBpL2xpc3QtYWdlbnRzP3NwYWNlPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHNwYWNlKX0mc2l6ZT0ke2VuY29kZVVSSUNvbXBvbmVudChzaXplIHx8IDEyKX0mcGFnZU5vPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHBhZ2VObyB8fCAwKX1gO1xuICAgICAgICBpZiAoYWRkQWdlbnRJbmZvKSB7XG4gICAgICAgICAgYmFja2VuZFVybCArPSBgJmFkZEFnZW50SW5mbz0ke2VuY29kZVVSSUNvbXBvbmVudChhZGRBZ2VudEluZm8pfWA7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBleHRlcm5hbFJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYmFja2VuZFVybCwge1xuICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgJ3gtYXBpLWtleSc6IGFwaUtleSxcbiAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB0aW1lb3V0OiB0aW1lb3V0LFxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAoIWV4dGVybmFsUmVzcG9uc2Uub2spIHtcbiAgICAgICAgICBjb25zdCBlcnJvclRleHQgPSBhd2FpdCBleHRlcm5hbFJlc3BvbnNlLnRleHQoKTtcbiAgICAgICAgICBsb2dnZXIuZXJyb3IoYFtjaGF0X2FwcF0gTGlzdCBhZ2VudHMgQVBJIGVycm9yOiAke2Vycm9yVGV4dH1gKTtcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgICAgc3RhdHVzQ29kZTogZXh0ZXJuYWxSZXNwb25zZS5zdGF0dXMsXG4gICAgICAgICAgICBib2R5OiBgTGlzdCBhZ2VudHMgQVBJIGVycm9yOiAke2V4dGVybmFsUmVzcG9uc2Uuc3RhdHVzVGV4dH1gLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGV4dGVybmFsUmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiBkYXRhIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGxvZ2dlci5lcnJvcihgW2NoYXRfYXBwXSBFcnJvciBpbiBsaXN0IGFnZW50cyByZXF1ZXN0OiAke2Vycn1gKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmludGVybmFsRXJyb3IoeyBib2R5OiBgU2VydmVyIGVycm9yOiAke2Vyci5tZXNzYWdlfWAgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xufSJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBLElBQUFBLGFBQUEsR0FBQUMsT0FBQTtBQUVBLElBQUFDLFVBQUEsR0FBQUMsc0JBQUEsQ0FBQUYsT0FBQTtBQUFnQzs7QUFHekIsU0FBU0csWUFBWUEsQ0FBQ0MsTUFBZSxFQUFFQyxNQUFjLEVBQUVDLE1BQWMsRUFBRUMsY0FBc0IsRUFBRUMsT0FBZSxFQUFFO0VBQ3JIO0FBQ0Y7QUFDQTtBQUNBO0VBQ0VKLE1BQU0sQ0FBQ0ssR0FBRyxDQUNSO0lBQ0VDLElBQUksRUFBRSxzQkFBc0I7SUFDNUJDLFFBQVEsRUFBRTtNQUNSQyxLQUFLLEVBQUVDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNuQkMsTUFBTSxFQUFFRixvQkFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQztRQUN2QkMsVUFBVSxFQUFFSixvQkFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQztRQUMzQkUsS0FBSyxFQUFFTCxvQkFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQztRQUN0QkcsSUFBSSxFQUFFTixvQkFBTSxDQUFDTyxLQUFLLENBQUNQLG9CQUFNLENBQUNRLE1BQU0sQ0FBQztVQUFFQyxZQUFZLEVBQUU7UUFBRSxDQUFDLENBQUMsQ0FBQztRQUN0REMsSUFBSSxFQUFFVixvQkFBTSxDQUFDTyxLQUFLLENBQUNQLG9CQUFNLENBQUNRLE1BQU0sQ0FBQztVQUFFQyxZQUFZLEVBQUU7UUFBRyxDQUFDLENBQUM7TUFDeEQsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9FLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQUs7SUFDcEMsSUFBSTtNQUNGLE1BQU07UUFBRVgsTUFBTTtRQUFFRSxVQUFVO1FBQUVDLEtBQUs7UUFBRUMsSUFBSTtRQUFFSTtNQUFLLENBQUMsR0FBR0UsT0FBTyxDQUFDYixLQUFLO01BQy9ELE1BQU1lLFVBQVUsR0FBSSxHQUFFcEIsY0FBZSxvQ0FBbUNxQixrQkFBa0IsQ0FBQ2IsTUFBTSxDQUFFLGVBQWNhLGtCQUFrQixDQUFDWCxVQUFVLENBQUUsVUFBU1csa0JBQWtCLENBQUNWLEtBQUssQ0FBRSxTQUFRQyxJQUFLLFNBQVFJLElBQUssRUFBQztNQUU5TSxNQUFNTSxnQkFBZ0IsR0FBRyxNQUFNLElBQUFDLGtCQUFLLEVBQUNILFVBQVUsRUFBRTtRQUMvQ0ksTUFBTSxFQUFFLEtBQUs7UUFDYkMsT0FBTyxFQUFFO1VBQ1AsV0FBVyxFQUFFMUIsTUFBTTtVQUNuQixjQUFjLEVBQUU7UUFDbEIsQ0FBQztRQUNERSxPQUFPLEVBQUVBO01BQ1gsQ0FBQyxDQUFDO01BRUYsSUFBSSxDQUFDcUIsZ0JBQWdCLENBQUNJLEVBQUUsRUFBRTtRQUN4QixNQUFNQyxTQUFTLEdBQUcsTUFBTUwsZ0JBQWdCLENBQUNNLElBQUksQ0FBQyxDQUFDO1FBQy9DOUIsTUFBTSxDQUFDK0IsS0FBSyxDQUFFLGdDQUErQkYsU0FBVSxFQUFDLENBQUM7UUFDekQsT0FBT1IsUUFBUSxDQUFDVyxXQUFXLENBQUM7VUFDMUJDLFVBQVUsRUFBRVQsZ0JBQWdCLENBQUNVLE1BQU07VUFDbkNDLElBQUksRUFBRyxxQkFBb0JYLGdCQUFnQixDQUFDWSxVQUFXO1FBQ3pELENBQUMsQ0FBQztNQUNKO01BRUEsTUFBTUMsSUFBSSxHQUFHLE1BQU1iLGdCQUFnQixDQUFDYyxJQUFJLENBQUMsQ0FBQztNQUMxQyxPQUFPakIsUUFBUSxDQUFDTyxFQUFFLENBQUM7UUFBRU8sSUFBSSxFQUFFRTtNQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDLENBQUMsT0FBT0UsR0FBRyxFQUFFO01BQ1p2QyxNQUFNLENBQUMrQixLQUFLLENBQUUsdUNBQXNDUSxHQUFJLEVBQUMsQ0FBQztNQUMxRCxPQUFPbEIsUUFBUSxDQUFDbUIsYUFBYSxDQUFDO1FBQUVMLElBQUksRUFBRyxpQkFBZ0JJLEdBQUcsQ0FBQ0UsT0FBUTtNQUFFLENBQUMsQ0FBQztJQUN6RTtFQUNGLENBQ0YsQ0FBQzs7RUFFRDtBQUNGO0FBQ0E7QUFDQTtFQUNFMUMsTUFBTSxDQUFDMkMsR0FBRyxDQUNSO0lBQ0VyQyxJQUFJLEVBQUUsd0JBQXdCO0lBQzlCQyxRQUFRLEVBQUU7TUFDUjZCLElBQUksRUFBRTNCLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNsQkMsTUFBTSxFQUFFRixvQkFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQztRQUN2QmdDLGNBQWMsRUFBRW5DLG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDO1FBQy9CRSxLQUFLLEVBQUVMLG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDO1FBQ3RCaUMsSUFBSSxFQUFFcEMsb0JBQU0sQ0FBQ0csTUFBTSxDQUFDO1VBQUVrQyxTQUFTLEVBQUUsQ0FBQztVQUFFQyxTQUFTLEVBQUU7UUFBSSxDQUFDO01BQ3RELENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPM0IsT0FBTyxFQUFFQyxPQUFPLEVBQUVDLFFBQVEsS0FBSztJQUNwQyxJQUFJO01BQ0YsTUFBTTtRQUFFWCxNQUFNO1FBQUVpQyxjQUFjO1FBQUU5QixLQUFLO1FBQUUrQjtNQUFLLENBQUMsR0FBR3hCLE9BQU8sQ0FBQ2UsSUFBSTtNQUM1RCxNQUFNYixVQUFVLEdBQUksR0FBRXBCLGNBQWUsd0JBQXVCO01BRTVELE1BQU1zQixnQkFBZ0IsR0FBRyxNQUFNLElBQUFDLGtCQUFLLEVBQUNILFVBQVUsRUFBRTtRQUMvQ0ksTUFBTSxFQUFFLEtBQUs7UUFDYkMsT0FBTyxFQUFFO1VBQ1AsV0FBVyxFQUFFMUIsTUFBTTtVQUNuQixjQUFjLEVBQUU7UUFDbEIsQ0FBQztRQUNEa0MsSUFBSSxFQUFFWSxJQUFJLENBQUNDLFNBQVMsQ0FBQztVQUFFdEMsTUFBTTtVQUFFaUMsY0FBYztVQUFFOUIsS0FBSztVQUFFK0I7UUFBSyxDQUFDLENBQUM7UUFDN0R6QyxPQUFPLEVBQUVBO01BQ1gsQ0FBQyxDQUFDO01BRUYsSUFBSSxDQUFDcUIsZ0JBQWdCLENBQUNJLEVBQUUsRUFBRTtRQUN4QixNQUFNQyxTQUFTLEdBQUcsTUFBTUwsZ0JBQWdCLENBQUNNLElBQUksQ0FBQyxDQUFDO1FBQy9DOUIsTUFBTSxDQUFDK0IsS0FBSyxDQUFFLHFDQUFvQ0YsU0FBVSxFQUFDLENBQUM7UUFDOUQsT0FBT1IsUUFBUSxDQUFDVyxXQUFXLENBQUM7VUFDMUJDLFVBQVUsRUFBRVQsZ0JBQWdCLENBQUNVLE1BQU07VUFDbkNDLElBQUksRUFBRywwQkFBeUJYLGdCQUFnQixDQUFDWSxVQUFXO1FBQzlELENBQUMsQ0FBQztNQUNKO01BRUEsTUFBTUMsSUFBSSxHQUFHLE1BQU1iLGdCQUFnQixDQUFDYyxJQUFJLENBQUMsQ0FBQztNQUMxQyxPQUFPakIsUUFBUSxDQUFDTyxFQUFFLENBQUM7UUFBRU8sSUFBSSxFQUFFRTtNQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDLENBQUMsT0FBT0UsR0FBRyxFQUFFO01BQ1p2QyxNQUFNLENBQUMrQixLQUFLLENBQUUsZ0RBQStDUSxHQUFJLEVBQUMsQ0FBQztNQUNuRSxPQUFPbEIsUUFBUSxDQUFDbUIsYUFBYSxDQUFDO1FBQUVMLElBQUksRUFBRyxpQkFBZ0JJLEdBQUcsQ0FBQ0UsT0FBUTtNQUFFLENBQUMsQ0FBQztJQUN6RTtFQUNGLENBQ0YsQ0FBQzs7RUFFRDtBQUNGO0FBQ0E7QUFDQTtFQUNFMUMsTUFBTSxDQUFDa0QsSUFBSSxDQUNUO0lBQ0U1QyxJQUFJLEVBQUUsd0JBQXdCO0lBQzlCQyxRQUFRLEVBQUU7TUFDUjZCLElBQUksRUFBRTNCLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNsQmtDLGNBQWMsRUFBRW5DLG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDO1FBQy9CRSxLQUFLLEVBQUVMLG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDO1FBQ3RCdUMsSUFBSSxFQUFFMUMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1VBQ2xCQyxNQUFNLEVBQUVGLG9CQUFNLENBQUNHLE1BQU0sQ0FBQztRQUN4QixDQUFDLENBQUM7UUFDRlEsT0FBTyxFQUFFWCxvQkFBTSxDQUFDQyxNQUFNLENBQUM7VUFDckIwQyxNQUFNLEVBQUUzQyxvQkFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQztVQUN2QnlDLFdBQVcsRUFBRTVDLG9CQUFNLENBQUNHLE1BQU0sQ0FBQztRQUM3QixDQUFDLENBQUM7UUFDRjBDLFFBQVEsRUFBRTdDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztVQUN0QjZDLFlBQVksRUFBRTlDLG9CQUFNLENBQUMrQyxLQUFLLENBQUMsQ0FBQy9DLG9CQUFNLENBQUNnRCxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUVoRCxvQkFBTSxDQUFDZ0QsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7VUFDMUVDLE9BQU8sRUFBRWpELG9CQUFNLENBQUNPLEtBQUssQ0FBQ1Asb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUM7UUFDdkMsQ0FBQztNQUNILENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPUSxPQUFPLEVBQUVDLE9BQU8sRUFBRUMsUUFBUSxLQUFLO0lBQ3BDLElBQUk7TUFDRixNQUFNcUMsWUFBWSxHQUFHdEMsT0FBTyxDQUFDZSxJQUFJO01BQ2pDLE1BQU1iLFVBQVUsR0FBSSxHQUFFcEIsY0FBZSxlQUFjO01BQ25ELE1BQU1zQixnQkFBZ0IsR0FBRyxNQUFNLElBQUFDLGtCQUFLLEVBQUNILFVBQVUsRUFBRTtRQUMvQ0ksTUFBTSxFQUFFLE1BQU07UUFDZEMsT0FBTyxFQUFFO1VBQ1AsV0FBVyxFQUFFMUIsTUFBTTtVQUNuQixjQUFjLEVBQUU7UUFDbEIsQ0FBQztRQUNEa0MsSUFBSSxFQUFFWSxJQUFJLENBQUNDLFNBQVMsQ0FBQ1UsWUFBWTtNQUNuQyxDQUFDLENBQUM7TUFFRixJQUFJLENBQUNsQyxnQkFBZ0IsQ0FBQ0ksRUFBRSxFQUFFO1FBQ3hCLE1BQU1DLFNBQVMsR0FBRyxNQUFNTCxnQkFBZ0IsQ0FBQ00sSUFBSSxDQUFDLENBQUM7UUFDL0M5QixNQUFNLENBQUMrQixLQUFLLENBQUUsc0NBQXFDRixTQUFVLEVBQUMsQ0FBQztRQUMvRCxPQUFPUixRQUFRLENBQUNXLFdBQVcsQ0FBQztVQUMxQkMsVUFBVSxFQUFFVCxnQkFBZ0IsQ0FBQ1UsTUFBTTtVQUNuQ0MsSUFBSSxFQUFHLHVCQUFzQlgsZ0JBQWdCLENBQUNZLFVBQVc7UUFDM0QsQ0FBQyxDQUFDO01BQ0o7TUFFQSxNQUFNQyxJQUFJLEdBQUcsTUFBTWIsZ0JBQWdCLENBQUNjLElBQUksQ0FBQyxDQUFDO01BQzFDLE9BQU9qQixRQUFRLENBQUNPLEVBQUUsQ0FBQztRQUFFTyxJQUFJLEVBQUVFO01BQUssQ0FBQyxDQUFDO0lBQ3BDLENBQUMsQ0FBQyxPQUFPRSxHQUFHLEVBQUU7TUFDWnZDLE1BQU0sQ0FBQytCLEtBQUssQ0FBRSx5Q0FBd0NRLEdBQUksRUFBQyxDQUFDO01BQzVEdkMsTUFBTSxDQUFDK0IsS0FBSyxDQUFFLDJCQUEwQlEsR0FBRyxDQUFDb0IsS0FBTSxFQUFDLENBQUM7TUFDcEQsT0FBT3RDLFFBQVEsQ0FBQ21CLGFBQWEsQ0FBQztRQUFFTCxJQUFJLEVBQUcsaUJBQWdCSSxHQUFHLENBQUNFLE9BQVE7TUFBRSxDQUFDLENBQUM7SUFDekU7RUFDRixDQUNGLENBQUM7RUFDRDtBQUNGO0FBQ0E7QUFDQTtFQUNFMUMsTUFBTSxDQUFDSyxHQUFHLENBQ1I7SUFDRUMsSUFBSSxFQUFFLHNCQUFzQjtJQUM1QkMsUUFBUSxFQUFFO0VBQ1osQ0FBQyxFQUNELE9BQU9hLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQUs7SUFDcEMsT0FBT0EsUUFBUSxDQUFDTyxFQUFFLENBQUM7TUFDakJPLElBQUksRUFBRTtRQUNKaEM7TUFDRjtJQUNGLENBQUMsQ0FBQztFQUNKLENBQ0YsQ0FBQzs7RUFFRDtBQUNGO0FBQ0E7QUFDQTtFQUNFSixNQUFNLENBQUNLLEdBQUcsQ0FDUjtJQUNFQyxJQUFJLEVBQUUsaUNBQWlDO0lBQ3ZDQyxRQUFRLEVBQUU7TUFDUkMsS0FBSyxFQUFFQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbkJDLE1BQU0sRUFBRUYsb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUM7UUFDdkJpRCxpQkFBaUIsRUFBRXBELG9CQUFNLENBQUNPLEtBQUssQ0FBQ1Asb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNoRGtELE9BQU8sRUFBRXJELG9CQUFNLENBQUNPLEtBQUssQ0FBQ1Asb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUM7TUFDdkMsQ0FBQyxFQUFFO1FBQUVtRCxRQUFRLEVBQUU7TUFBUyxDQUFDO0lBQzNCO0VBQ0YsQ0FBQyxFQUNELE9BQU8zQyxPQUFPLEVBQUVDLE9BQU8sRUFBRUMsUUFBUSxLQUFLO0lBQ3BDLE1BQU07TUFBRVgsTUFBTTtNQUFFa0QsaUJBQWlCO01BQUVDO0lBQVEsQ0FBQyxHQUFHekMsT0FBTyxDQUFDYixLQUFLO0lBRTVELElBQUllLFVBQVUsR0FBSSxHQUFFcEIsY0FBZSxpQ0FBZ0NxQixrQkFBa0IsQ0FBQ2IsTUFBTSxDQUFFLEVBQUM7SUFDL0YsSUFBSWtELGlCQUFpQixFQUFFO01BQ3JCdEMsVUFBVSxJQUFLLHNCQUFxQkMsa0JBQWtCLENBQUNxQyxpQkFBaUIsQ0FBRSxFQUFDO0lBQzdFO0lBQ0EsSUFBSUMsT0FBTyxFQUFFO01BQ1h2QyxVQUFVLElBQUssVUFBU0Msa0JBQWtCLENBQUNzQyxPQUFPLENBQUUsRUFBQztJQUN2RDtJQUVBLElBQUk7TUFDRixNQUFNckMsZ0JBQWdCLEdBQUcsTUFBTSxJQUFBQyxrQkFBSyxFQUFDSCxVQUFVLEVBQUU7UUFDL0NJLE1BQU0sRUFBRSxLQUFLO1FBQ2JDLE9BQU8sRUFBRTtVQUNQLFdBQVcsRUFBRTFCLE1BQU07VUFDbkIsY0FBYyxFQUFFO1FBQ2xCLENBQUM7UUFDREUsT0FBTyxFQUFFQSxPQUFPLENBQUU7TUFDcEIsQ0FBQyxDQUFDO01BRUYsSUFBSSxDQUFDcUIsZ0JBQWdCLENBQUNJLEVBQUUsRUFBRTtRQUN4QixPQUFPUCxRQUFRLENBQUNXLFdBQVcsQ0FBQztVQUMxQkMsVUFBVSxFQUFFVCxnQkFBZ0IsQ0FBQ1UsTUFBTTtVQUNuQ0MsSUFBSSxFQUFHLHVCQUFzQlgsZ0JBQWdCLENBQUNZLFVBQVc7UUFDM0QsQ0FBQyxDQUFDO01BQ0o7TUFFQSxNQUFNQyxJQUFJLEdBQUcsTUFBTWIsZ0JBQWdCLENBQUNjLElBQUksQ0FBQyxDQUFDO01BQzFDLE9BQU9qQixRQUFRLENBQUNPLEVBQUUsQ0FBQztRQUFFTyxJQUFJLEVBQUVFO01BQUssQ0FBQyxDQUFDO0lBQ3BDLENBQUMsQ0FBQyxPQUFPRSxHQUFHLEVBQUU7TUFDWnZDLE1BQU0sQ0FBQytCLEtBQUssQ0FBRSw2Q0FBNENRLEdBQUksRUFBQyxDQUFDO01BQ2hFLE9BQU9sQixRQUFRLENBQUNtQixhQUFhLENBQUM7UUFBRUwsSUFBSSxFQUFHLGlCQUFnQkksR0FBSTtNQUFFLENBQUMsQ0FBQztJQUNqRTtFQUNGLENBQ0YsQ0FBQzs7RUFFRDtBQUNGO0FBQ0E7QUFDQTtFQUNFeEMsTUFBTSxDQUFDSyxHQUFHLENBQ1I7SUFDRUMsSUFBSSxFQUFFLGlDQUFpQztJQUN2Q0MsUUFBUSxFQUFFO01BQ1JDLEtBQUssRUFBRUMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ25Ca0MsY0FBYyxFQUFFbkMsb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUM7UUFDL0JELE1BQU0sRUFBRUYsb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUM7UUFDdkJpRCxpQkFBaUIsRUFBRXBELG9CQUFNLENBQUNPLEtBQUssQ0FBQ1Asb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNoRGtELE9BQU8sRUFBRXJELG9CQUFNLENBQUNPLEtBQUssQ0FBQ1Asb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUM7TUFDdkMsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9RLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQUs7SUFDcEMsTUFBTTtNQUFFc0IsY0FBYztNQUFFakMsTUFBTTtNQUFFa0QsaUJBQWlCO01BQUVDO0lBQVEsQ0FBQyxHQUFHekMsT0FBTyxDQUFDYixLQUFLO0lBRTVFLElBQUllLFVBQVUsR0FBSSxHQUFFcEIsY0FBZSx5Q0FBd0NxQixrQkFBa0IsQ0FBQ29CLGNBQWMsQ0FBRSxXQUFVcEIsa0JBQWtCLENBQUNiLE1BQU0sQ0FBRSxFQUFDO0lBQ3BKLElBQUlrRCxpQkFBaUIsRUFBRTtNQUNyQnRDLFVBQVUsSUFBSyxzQkFBcUJDLGtCQUFrQixDQUFDcUMsaUJBQWlCLENBQUUsRUFBQztJQUM3RTtJQUNBLElBQUlDLE9BQU8sRUFBRTtNQUNYdkMsVUFBVSxJQUFLLFVBQVNDLGtCQUFrQixDQUFDc0MsT0FBTyxDQUFFLEVBQUM7SUFDdkQ7SUFFQSxJQUFJO01BQ0YsTUFBTXJDLGdCQUFnQixHQUFHLE1BQU0sSUFBQUMsa0JBQUssRUFBQ0gsVUFBVSxFQUFFO1FBQy9DSSxNQUFNLEVBQUUsS0FBSztRQUNiQyxPQUFPLEVBQUU7VUFDUCxXQUFXLEVBQUUxQixNQUFNO1VBQ25CLGNBQWMsRUFBRTtRQUNsQixDQUFDO1FBQ0RFLE9BQU8sRUFBRUEsT0FBTyxDQUFFO01BQ3BCLENBQUMsQ0FBQztNQUVGLElBQUksQ0FBQ3FCLGdCQUFnQixDQUFDSSxFQUFFLEVBQUU7UUFDeEIsT0FBT1AsUUFBUSxDQUFDVyxXQUFXLENBQUM7VUFDMUJDLFVBQVUsRUFBRVQsZ0JBQWdCLENBQUNVLE1BQU07VUFDbkNDLElBQUksRUFBRyx1QkFBc0JYLGdCQUFnQixDQUFDWSxVQUFXO1FBQzNELENBQUMsQ0FBQztNQUNKO01BRUEsTUFBTUMsSUFBSSxHQUFHLE1BQU1iLGdCQUFnQixDQUFDYyxJQUFJLENBQUMsQ0FBQztNQUMxQyxPQUFPakIsUUFBUSxDQUFDTyxFQUFFLENBQUM7UUFBRU8sSUFBSSxFQUFFRTtNQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDLENBQUMsT0FBT0UsR0FBRyxFQUFFO01BQ1p2QyxNQUFNLENBQUMrQixLQUFLLENBQUUsNkNBQTRDUSxHQUFJLEVBQUMsQ0FBQztNQUNoRSxPQUFPbEIsUUFBUSxDQUFDbUIsYUFBYSxDQUFDO1FBQUVMLElBQUksRUFBRyxpQkFBZ0JJLEdBQUk7TUFBRSxDQUFDLENBQUM7SUFDakU7RUFDRixDQUNGLENBQUM7O0VBRUQ7QUFDRjtBQUNBO0FBQ0E7RUFDRXhDLE1BQU0sQ0FBQ0ssR0FBRyxDQUNSO0lBQ0VDLElBQUksRUFBRSxvQkFBb0I7SUFDMUJDLFFBQVEsRUFBRTtNQUNSQyxLQUFLLEVBQUVDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNuQkMsTUFBTSxFQUFFRixvQkFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQztRQUN2Qm9ELEtBQUssRUFBRXZELG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDO1FBQ3RCZ0MsY0FBYyxFQUFFbkMsb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUM7UUFDL0JrRCxPQUFPLEVBQUVyRCxvQkFBTSxDQUFDTyxLQUFLLENBQUNQLG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDdENxRCxPQUFPLEVBQUV4RCxvQkFBTSxDQUFDTyxLQUFLLENBQUNQLG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDO01BQ3ZDLENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPUSxPQUFPLEVBQUVDLE9BQU8sRUFBRUMsUUFBUSxLQUFLO0lBQ3BDLElBQUk7TUFDRixNQUFNO1FBQUVYLE1BQU07UUFBRXFELEtBQUs7UUFBRXBCLGNBQWM7UUFBRWtCLE9BQU87UUFBRUc7TUFBUSxDQUFDLEdBQUc1QyxPQUFPLENBQUNiLEtBQUs7TUFDekUsSUFBSWUsVUFBVSxHQUFJLEdBQUVwQixjQUFlLG9CQUFtQnFCLGtCQUFrQixDQUFDYixNQUFNLENBQUUsVUFBU2Esa0JBQWtCLENBQUN3QyxLQUFLLENBQUUsbUJBQWtCeEMsa0JBQWtCLENBQUNvQixjQUFjLENBQUUsVUFBU3BCLGtCQUFrQixDQUFDc0MsT0FBTyxDQUFFLEVBQUM7TUFFL00sSUFBSUcsT0FBTyxFQUFFO1FBQ1gxQyxVQUFVLElBQUssWUFBV0Msa0JBQWtCLENBQUN5QyxPQUFPLENBQUUsRUFBQztNQUN6RDtNQUVBLE1BQU14QyxnQkFBZ0IsR0FBRyxNQUFNLElBQUFDLGtCQUFLLEVBQUNILFVBQVUsRUFBRTtRQUMvQ0ksTUFBTSxFQUFFLE1BQU07UUFDZEMsT0FBTyxFQUFFO1VBQ1AsV0FBVyxFQUFFMUIsTUFBTTtVQUNuQixjQUFjLEVBQUU7UUFDbEIsQ0FBQztRQUNERSxPQUFPLEVBQUVBLE9BQU8sQ0FBRTtNQUNwQixDQUFDLENBQUM7TUFFRixJQUFJLENBQUNxQixnQkFBZ0IsQ0FBQ0ksRUFBRSxFQUFFO1FBQ3hCNUIsTUFBTSxDQUFDK0IsS0FBSyxDQUFFLG9DQUFtQ1AsZ0JBQWdCLENBQUNVLE1BQU8sSUFBR1YsZ0JBQWdCLENBQUNZLFVBQVcsRUFBQyxDQUFDO1FBQzFHLE9BQU9mLFFBQVEsQ0FBQ1csV0FBVyxDQUFDO1VBQzFCQyxVQUFVLEVBQUVULGdCQUFnQixDQUFDVSxNQUFNO1VBQ25DQyxJQUFJLEVBQUcsdUJBQXNCWCxnQkFBZ0IsQ0FBQ1ksVUFBVztRQUMzRCxDQUFDLENBQUM7TUFDSjtNQUVBLE1BQU1DLElBQUksR0FBRyxNQUFNYixnQkFBZ0IsQ0FBQ2MsSUFBSSxDQUFDLENBQUM7TUFDMUMsT0FBT2pCLFFBQVEsQ0FBQ08sRUFBRSxDQUFDO1FBQUVPLElBQUksRUFBRUU7TUFBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQyxDQUFDLE9BQU9FLEdBQUcsRUFBRTtNQUNadkMsTUFBTSxDQUFDK0IsS0FBSyxDQUFFLHVDQUFzQ1EsR0FBSSxFQUFDLENBQUM7TUFDMUQsT0FBT2xCLFFBQVEsQ0FBQ21CLGFBQWEsQ0FBQztRQUFFTCxJQUFJLEVBQUcsaUJBQWdCSSxHQUFJO01BQUUsQ0FBQyxDQUFDO0lBQ2pFO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0FBQ0Y7QUFDQTtBQUNBO0VBQ0V4QyxNQUFNLENBQUNLLEdBQUcsQ0FDUjtJQUNFQyxJQUFJLEVBQUUsNkJBQTZCO0lBQ25DQyxRQUFRLEVBQUU7TUFDUkMsS0FBSyxFQUFFQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbkJJLEtBQUssRUFBRUwsb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUM7UUFDdEJzRCxZQUFZLEVBQUV6RCxvQkFBTSxDQUFDRyxNQUFNLENBQUM7VUFBRWtDLFNBQVMsRUFBRTtRQUFFLENBQUMsQ0FBQztRQUM3QzNCLElBQUksRUFBRVYsb0JBQU0sQ0FBQ08sS0FBSyxDQUFDUCxvQkFBTSxDQUFDUSxNQUFNLENBQUM7VUFBRUMsWUFBWSxFQUFFO1FBQUcsQ0FBQyxDQUFDLENBQUM7UUFDdkRpRCxNQUFNLEVBQUUxRCxvQkFBTSxDQUFDTyxLQUFLLENBQUNQLG9CQUFNLENBQUNRLE1BQU0sQ0FBQztVQUFFQyxZQUFZLEVBQUU7UUFBRSxDQUFDLENBQUM7TUFDekQsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9FLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQUs7SUFDcEMsSUFBSTtNQUNGLE1BQU07UUFBRVIsS0FBSztRQUFFb0QsWUFBWTtRQUFFL0MsSUFBSTtRQUFFZ0Q7TUFBTyxDQUFDLEdBQUc5QyxPQUFPLENBQUNiLEtBQUs7TUFDM0QsSUFBSWUsVUFBVSxHQUFJLEdBQUVwQixjQUFlLDRCQUEyQnFCLGtCQUFrQixDQUFDVixLQUFLLENBQUUsaUJBQWdCVSxrQkFBa0IsQ0FBQzBDLFlBQVksQ0FBRSxTQUFRMUMsa0JBQWtCLENBQUNMLElBQUksSUFBSSxFQUFFLENBQUUsV0FBVUssa0JBQWtCLENBQUMyQyxNQUFNLElBQUksQ0FBQyxDQUFFLEVBQUM7TUFFM04sTUFBTTFDLGdCQUFnQixHQUFHLE1BQU0sSUFBQUMsa0JBQUssRUFBQ0gsVUFBVSxFQUFFO1FBQy9DSSxNQUFNLEVBQUUsS0FBSztRQUNiQyxPQUFPLEVBQUU7VUFDUCxXQUFXLEVBQUUxQixNQUFNO1VBQ25CLGNBQWMsRUFBRTtRQUNsQixDQUFDO1FBQ0RFLE9BQU8sRUFBRUE7TUFDWCxDQUFDLENBQUM7TUFFRixJQUFJLENBQUNxQixnQkFBZ0IsQ0FBQ0ksRUFBRSxFQUFFO1FBQ3hCLE1BQU1DLFNBQVMsR0FBRyxNQUFNTCxnQkFBZ0IsQ0FBQ00sSUFBSSxDQUFDLENBQUM7UUFDL0M5QixNQUFNLENBQUMrQixLQUFLLENBQUUsdUNBQXNDRixTQUFVLEVBQUMsQ0FBQztRQUNoRSxPQUFPUixRQUFRLENBQUNXLFdBQVcsQ0FBQztVQUMxQkMsVUFBVSxFQUFFVCxnQkFBZ0IsQ0FBQ1UsTUFBTTtVQUNuQ0MsSUFBSSxFQUFHLDRCQUEyQlgsZ0JBQWdCLENBQUNZLFVBQVc7UUFDaEUsQ0FBQyxDQUFDO01BQ0o7TUFFQSxNQUFNQyxJQUFJLEdBQUcsTUFBTWIsZ0JBQWdCLENBQUNjLElBQUksQ0FBQyxDQUFDO01BQzFDLE9BQU9qQixRQUFRLENBQUNPLEVBQUUsQ0FBQztRQUFFTyxJQUFJLEVBQUVFO01BQUssQ0FBQyxDQUFDO0lBQ3BDLENBQUMsQ0FBQyxPQUFPRSxHQUFHLEVBQUU7TUFDWnZDLE1BQU0sQ0FBQytCLEtBQUssQ0FBRSw4Q0FBNkNRLEdBQUksRUFBQyxDQUFDO01BQ2pFLE9BQU9sQixRQUFRLENBQUNtQixhQUFhLENBQUM7UUFBRUwsSUFBSSxFQUFHLGlCQUFnQkksR0FBRyxDQUFDRSxPQUFRO01BQUUsQ0FBQyxDQUFDO0lBQ3pFO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0FBQ0Y7QUFDQTtBQUNBO0VBQ0UxQyxNQUFNLENBQUNLLEdBQUcsQ0FDUjtJQUNFQyxJQUFJLEVBQUUsMkJBQTJCO0lBQ2pDQyxRQUFRLEVBQUU7TUFDUkMsS0FBSyxFQUFFQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbkJJLEtBQUssRUFBRUwsb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUM7UUFDdEJ3RCxZQUFZLEVBQUUzRCxvQkFBTSxDQUFDTyxLQUFLLENBQUNQLG9CQUFNLENBQUM0RCxPQUFPLENBQUM7VUFBRW5ELFlBQVksRUFBRTtRQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ25FQyxJQUFJLEVBQUVWLG9CQUFNLENBQUNPLEtBQUssQ0FBQ1Asb0JBQU0sQ0FBQ1EsTUFBTSxDQUFDO1VBQUVDLFlBQVksRUFBRTtRQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ3ZEaUQsTUFBTSxFQUFFMUQsb0JBQU0sQ0FBQ08sS0FBSyxDQUFDUCxvQkFBTSxDQUFDUSxNQUFNLENBQUM7VUFBRUMsWUFBWSxFQUFFO1FBQUUsQ0FBQyxDQUFDO01BQ3pELENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPRSxPQUFPLEVBQUVDLE9BQU8sRUFBRUMsUUFBUSxLQUFLO0lBQ3BDLElBQUk7TUFDRixNQUFNO1FBQUVSLEtBQUs7UUFBRXNELFlBQVk7UUFBRWpELElBQUk7UUFBRWdEO01BQU8sQ0FBQyxHQUFHOUMsT0FBTyxDQUFDYixLQUFLO01BQzNELElBQUllLFVBQVUsR0FBSSxHQUFFcEIsY0FBZSwwQkFBeUJxQixrQkFBa0IsQ0FBQ1YsS0FBSyxDQUFFLFNBQVFVLGtCQUFrQixDQUFDTCxJQUFJLElBQUksRUFBRSxDQUFFLFdBQVVLLGtCQUFrQixDQUFDMkMsTUFBTSxJQUFJLENBQUMsQ0FBRSxFQUFDO01BQ3hLLElBQUlDLFlBQVksRUFBRTtRQUNoQjdDLFVBQVUsSUFBSyxpQkFBZ0JDLGtCQUFrQixDQUFDNEMsWUFBWSxDQUFFLEVBQUM7TUFDbkU7TUFFQSxNQUFNM0MsZ0JBQWdCLEdBQUcsTUFBTSxJQUFBQyxrQkFBSyxFQUFDSCxVQUFVLEVBQUU7UUFDL0NJLE1BQU0sRUFBRSxLQUFLO1FBQ2JDLE9BQU8sRUFBRTtVQUNQLFdBQVcsRUFBRTFCLE1BQU07VUFDbkIsY0FBYyxFQUFFO1FBQ2xCLENBQUM7UUFDREUsT0FBTyxFQUFFQTtNQUNYLENBQUMsQ0FBQztNQUVGLElBQUksQ0FBQ3FCLGdCQUFnQixDQUFDSSxFQUFFLEVBQUU7UUFDeEIsTUFBTUMsU0FBUyxHQUFHLE1BQU1MLGdCQUFnQixDQUFDTSxJQUFJLENBQUMsQ0FBQztRQUMvQzlCLE1BQU0sQ0FBQytCLEtBQUssQ0FBRSxxQ0FBb0NGLFNBQVUsRUFBQyxDQUFDO1FBQzlELE9BQU9SLFFBQVEsQ0FBQ1csV0FBVyxDQUFDO1VBQzFCQyxVQUFVLEVBQUVULGdCQUFnQixDQUFDVSxNQUFNO1VBQ25DQyxJQUFJLEVBQUcsMEJBQXlCWCxnQkFBZ0IsQ0FBQ1ksVUFBVztRQUM5RCxDQUFDLENBQUM7TUFDSjtNQUVBLE1BQU1DLElBQUksR0FBRyxNQUFNYixnQkFBZ0IsQ0FBQ2MsSUFBSSxDQUFDLENBQUM7TUFDMUMsT0FBT2pCLFFBQVEsQ0FBQ08sRUFBRSxDQUFDO1FBQUVPLElBQUksRUFBRUU7TUFBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQyxDQUFDLE9BQU9FLEdBQUcsRUFBRTtNQUNadkMsTUFBTSxDQUFDK0IsS0FBSyxDQUFFLDRDQUEyQ1EsR0FBSSxFQUFDLENBQUM7TUFDL0QsT0FBT2xCLFFBQVEsQ0FBQ21CLGFBQWEsQ0FBQztRQUFFTCxJQUFJLEVBQUcsaUJBQWdCSSxHQUFHLENBQUNFLE9BQVE7TUFBRSxDQUFDLENBQUM7SUFDekU7RUFDRixDQUNGLENBQUM7QUFDSCIsImlnbm9yZUxpc3QiOltdfQ==