"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ChatAppPlugin = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _index = require("./routes/index");
var _common = require("../common");
// plugins/chat_app/server/plugin.ts

// Declare plugin deps for `setup()`

class ChatAppPlugin {
  constructor(initializerContext) {
    (0, _defineProperty2.default)(this, "logger", void 0);
    (0, _defineProperty2.default)(this, "config", void 0);
    this.initializerContext = initializerContext;
    this.logger = initializerContext.logger.get();
    this.config = initializerContext.config.get();
  }
  async setup(core, plugins) {
    this.logger.info('[chat_app] Setup called');

    // 1) Register the Feature → shows “TowerTalk” in Roles → Kibana privileges
    plugins.features.registerKibanaFeature({
      id: 'chatApp',
      // must match your public app id
      name: 'TowerTalk',
      // label in the Roles UI
      category: _common.CONTROL_TOWER_CATEGORY,
      app: ['chatApp'],
      catalogue: ['chatApp'],
      privileges: {
        all: {
          app: ['chatApp'],
          catalogue: ['chatApp'],
          savedObject: {
            all: [],
            read: []
          },
          // add your saved object types if any
          api: ['chatApp-all'],
          // optional: tag if you want to guard routes by privilege
          ui: ['show', 'create', 'edit', 'admin'] // arbitrary UI caps surfaced to client
        },
        read: {
          app: ['chatApp'],
          catalogue: ['chatApp'],
          savedObject: {
            all: [],
            read: []
          },
          api: ['chatApp-read'],
          ui: ['show']
        }
      },
      subFeatures: []
    });

    // 2) Your routes
    const router = core.http.createRouter();
    (0, _index.defineRoutes)(router, this.logger, this.config.apiKey, this.config.mcp_client_url, this.config.timeout);
    return {};
  }
  start(core) {
    this.logger.info('[chat_app] Started');
    return {};
  }
  stop() {
    this.logger.info('[chat_app] Stopped');
  }
}
exports.ChatAppPlugin = ChatAppPlugin;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfaW5kZXgiLCJyZXF1aXJlIiwiX2NvbW1vbiIsIkNoYXRBcHBQbHVnaW4iLCJjb25zdHJ1Y3RvciIsImluaXRpYWxpemVyQ29udGV4dCIsIl9kZWZpbmVQcm9wZXJ0eTIiLCJkZWZhdWx0IiwibG9nZ2VyIiwiZ2V0IiwiY29uZmlnIiwic2V0dXAiLCJjb3JlIiwicGx1Z2lucyIsImluZm8iLCJmZWF0dXJlcyIsInJlZ2lzdGVyS2liYW5hRmVhdHVyZSIsImlkIiwibmFtZSIsImNhdGVnb3J5IiwiQ09OVFJPTF9UT1dFUl9DQVRFR09SWSIsImFwcCIsImNhdGFsb2d1ZSIsInByaXZpbGVnZXMiLCJhbGwiLCJzYXZlZE9iamVjdCIsInJlYWQiLCJhcGkiLCJ1aSIsInN1YkZlYXR1cmVzIiwicm91dGVyIiwiaHR0cCIsImNyZWF0ZVJvdXRlciIsImRlZmluZVJvdXRlcyIsImFwaUtleSIsIm1jcF9jbGllbnRfdXJsIiwidGltZW91dCIsInN0YXJ0Iiwic3RvcCIsImV4cG9ydHMiXSwic291cmNlcyI6WyJwbHVnaW4udHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gcGx1Z2lucy9jaGF0X2FwcC9zZXJ2ZXIvcGx1Z2luLnRzXG5pbXBvcnQge1xuICBDb3JlU2V0dXAsXG4gIENvcmVTdGFydCxcbiAgTG9nZ2VyLFxuICBQbHVnaW4sXG4gIFBsdWdpbkluaXRpYWxpemVyQ29udGV4dCxcbn0gZnJvbSAnQGtibi9jb3JlL3NlcnZlcic7XG5pbXBvcnQgdHlwZSB7IEZlYXR1cmVzUGx1Z2luU2V0dXAgfSBmcm9tICdAa2JuL2ZlYXR1cmVzLXBsdWdpbi9zZXJ2ZXInO1xuXG5pbXBvcnQgeyBkZWZpbmVSb3V0ZXMgfSBmcm9tICcuL3JvdXRlcy9pbmRleCc7XG5pbXBvcnQgeyBjb25maWcsIENoYXRBcHBDb25maWdUeXBlIH0gZnJvbSAnLi9jb25maWcnO1xuaW1wb3J0IHsgQ09OVFJPTF9UT1dFUl9DQVRFR09SWSB9IGZyb20gJy4uL2NvbW1vbic7XG5cblxuZXhwb3J0IGludGVyZmFjZSBDaGF0QXBwUGx1Z2luU2V0dXAge31cbmV4cG9ydCBpbnRlcmZhY2UgQ2hhdEFwcFBsdWdpblN0YXJ0IHt9XG5cbi8vIERlY2xhcmUgcGx1Z2luIGRlcHMgZm9yIGBzZXR1cCgpYFxuaW50ZXJmYWNlIFBsdWdpbnNTZXR1cCB7XG4gIGZlYXR1cmVzOiBGZWF0dXJlc1BsdWdpblNldHVwO1xufVxuaW50ZXJmYWNlIFBsdWdpbnNTdGFydCB7fVxuXG5leHBvcnQgY2xhc3MgQ2hhdEFwcFBsdWdpblxuICBpbXBsZW1lbnRzIFBsdWdpbjxDaGF0QXBwUGx1Z2luU2V0dXAsIENoYXRBcHBQbHVnaW5TdGFydCwgUGx1Z2luc1NldHVwLCBQbHVnaW5zU3RhcnQ+XG57XG4gIHByaXZhdGUgcmVhZG9ubHkgbG9nZ2VyOiBMb2dnZXI7XG4gIHByaXZhdGUgY29uZmlnPzogQ2hhdEFwcENvbmZpZ1R5cGU7XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSByZWFkb25seSBpbml0aWFsaXplckNvbnRleHQ6IFBsdWdpbkluaXRpYWxpemVyQ29udGV4dCkge1xuICAgIHRoaXMubG9nZ2VyID0gaW5pdGlhbGl6ZXJDb250ZXh0LmxvZ2dlci5nZXQoKTtcbiAgICB0aGlzLmNvbmZpZyA9IGluaXRpYWxpemVyQ29udGV4dC5jb25maWcuZ2V0PENoYXRBcHBDb25maWdUeXBlPigpO1xuICB9XG5cbiAgcHVibGljIGFzeW5jIHNldHVwKGNvcmU6IENvcmVTZXR1cCwgcGx1Z2luczogUGx1Z2luc1NldHVwKTogUHJvbWlzZTxDaGF0QXBwUGx1Z2luU2V0dXA+IHtcbiAgICB0aGlzLmxvZ2dlci5pbmZvKCdbY2hhdF9hcHBdIFNldHVwIGNhbGxlZCcpO1xuXG4gICAgLy8gMSkgUmVnaXN0ZXIgdGhlIEZlYXR1cmUg4oaSIHNob3dzIOKAnFRvd2VyVGFsa+KAnSBpbiBSb2xlcyDihpIgS2liYW5hIHByaXZpbGVnZXNcbiAgICBwbHVnaW5zLmZlYXR1cmVzLnJlZ2lzdGVyS2liYW5hRmVhdHVyZSh7XG4gICAgICBpZDogJ2NoYXRBcHAnLCAgICAgICAgICAgICAgIC8vIG11c3QgbWF0Y2ggeW91ciBwdWJsaWMgYXBwIGlkXG4gICAgICBuYW1lOiAnVG93ZXJUYWxrJywgICAgICAgICAgIC8vIGxhYmVsIGluIHRoZSBSb2xlcyBVSVxuICAgICAgY2F0ZWdvcnk6IENPTlRST0xfVE9XRVJfQ0FURUdPUlksXG4gICAgICBhcHA6IFsnY2hhdEFwcCddLFxuICAgICAgY2F0YWxvZ3VlOiBbJ2NoYXRBcHAnXSxcbiAgICAgIHByaXZpbGVnZXM6IHtcbiAgICAgICAgYWxsOiB7XG4gICAgICAgICAgYXBwOiBbJ2NoYXRBcHAnXSxcbiAgICAgICAgICBjYXRhbG9ndWU6IFsnY2hhdEFwcCddLFxuICAgICAgICAgIHNhdmVkT2JqZWN0OiB7IGFsbDogW10sIHJlYWQ6IFtdIH0sIC8vIGFkZCB5b3VyIHNhdmVkIG9iamVjdCB0eXBlcyBpZiBhbnlcbiAgICAgICAgICBhcGk6IFsnY2hhdEFwcC1hbGwnXSwgICAgICAgICAgICAgICAvLyBvcHRpb25hbDogdGFnIGlmIHlvdSB3YW50IHRvIGd1YXJkIHJvdXRlcyBieSBwcml2aWxlZ2VcbiAgICAgICAgICB1aTogWydzaG93JywgJ2NyZWF0ZScsICdlZGl0JywgJ2FkbWluJ10sIC8vIGFyYml0cmFyeSBVSSBjYXBzIHN1cmZhY2VkIHRvIGNsaWVudFxuICAgICAgICB9LFxuICAgICAgICByZWFkOiB7XG4gICAgICAgICAgYXBwOiBbJ2NoYXRBcHAnXSxcbiAgICAgICAgICBjYXRhbG9ndWU6IFsnY2hhdEFwcCddLFxuICAgICAgICAgIHNhdmVkT2JqZWN0OiB7IGFsbDogW10sIHJlYWQ6IFtdIH0sXG4gICAgICAgICAgYXBpOiBbJ2NoYXRBcHAtcmVhZCddLFxuICAgICAgICAgIHVpOiBbJ3Nob3cnXSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICBzdWJGZWF0dXJlczogW10sXG4gICAgfSk7XG5cbiAgICAvLyAyKSBZb3VyIHJvdXRlc1xuICAgIGNvbnN0IHJvdXRlciA9IGNvcmUuaHR0cC5jcmVhdGVSb3V0ZXIoKTtcbiAgICBkZWZpbmVSb3V0ZXMoXG4gICAgICByb3V0ZXIsXG4gICAgICB0aGlzLmxvZ2dlcixcbiAgICAgIHRoaXMuY29uZmlnLmFwaUtleSxcbiAgICAgIHRoaXMuY29uZmlnLm1jcF9jbGllbnRfdXJsLFxuICAgICAgdGhpcy5jb25maWcudGltZW91dFxuICAgICk7XG5cbiAgICByZXR1cm4ge307XG4gIH1cblxuICBwdWJsaWMgc3RhcnQoY29yZTogQ29yZVN0YXJ0KTogQ2hhdEFwcFBsdWdpblN0YXJ0IHtcbiAgICB0aGlzLmxvZ2dlci5pbmZvKCdbY2hhdF9hcHBdIFN0YXJ0ZWQnKTtcbiAgICByZXR1cm4ge307XG4gIH1cblxuICBwdWJsaWMgc3RvcCgpIHtcbiAgICB0aGlzLmxvZ2dlci5pbmZvKCdbY2hhdF9hcHBdIFN0b3BwZWQnKTtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQVVBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUVBLElBQUFDLE9BQUEsR0FBQUQsT0FBQTtBQVpBOztBQWtCQTs7QUFNTyxNQUFNRSxhQUFhLENBRTFCO0VBSUVDLFdBQVdBLENBQWtCQyxrQkFBNEMsRUFBRTtJQUFBLElBQUFDLGdCQUFBLENBQUFDLE9BQUE7SUFBQSxJQUFBRCxnQkFBQSxDQUFBQyxPQUFBO0lBQUEsS0FBOUNGLGtCQUE0QyxHQUE1Q0Esa0JBQTRDO0lBQ3ZFLElBQUksQ0FBQ0csTUFBTSxHQUFHSCxrQkFBa0IsQ0FBQ0csTUFBTSxDQUFDQyxHQUFHLENBQUMsQ0FBQztJQUM3QyxJQUFJLENBQUNDLE1BQU0sR0FBR0wsa0JBQWtCLENBQUNLLE1BQU0sQ0FBQ0QsR0FBRyxDQUFvQixDQUFDO0VBQ2xFO0VBRUEsTUFBYUUsS0FBS0EsQ0FBQ0MsSUFBZSxFQUFFQyxPQUFxQixFQUErQjtJQUN0RixJQUFJLENBQUNMLE1BQU0sQ0FBQ00sSUFBSSxDQUFDLHlCQUF5QixDQUFDOztJQUUzQztJQUNBRCxPQUFPLENBQUNFLFFBQVEsQ0FBQ0MscUJBQXFCLENBQUM7TUFDckNDLEVBQUUsRUFBRSxTQUFTO01BQWdCO01BQzdCQyxJQUFJLEVBQUUsV0FBVztNQUFZO01BQzdCQyxRQUFRLEVBQUVDLDhCQUFzQjtNQUNoQ0MsR0FBRyxFQUFFLENBQUMsU0FBUyxDQUFDO01BQ2hCQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7TUFDdEJDLFVBQVUsRUFBRTtRQUNWQyxHQUFHLEVBQUU7VUFDSEgsR0FBRyxFQUFFLENBQUMsU0FBUyxDQUFDO1VBQ2hCQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7VUFDdEJHLFdBQVcsRUFBRTtZQUFFRCxHQUFHLEVBQUUsRUFBRTtZQUFFRSxJQUFJLEVBQUU7VUFBRyxDQUFDO1VBQUU7VUFDcENDLEdBQUcsRUFBRSxDQUFDLGFBQWEsQ0FBQztVQUFnQjtVQUNwQ0MsRUFBRSxFQUFFLENBQUMsTUFBTSxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUU7UUFDM0MsQ0FBQztRQUNERixJQUFJLEVBQUU7VUFDSkwsR0FBRyxFQUFFLENBQUMsU0FBUyxDQUFDO1VBQ2hCQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUM7VUFDdEJHLFdBQVcsRUFBRTtZQUFFRCxHQUFHLEVBQUUsRUFBRTtZQUFFRSxJQUFJLEVBQUU7VUFBRyxDQUFDO1VBQ2xDQyxHQUFHLEVBQUUsQ0FBQyxjQUFjLENBQUM7VUFDckJDLEVBQUUsRUFBRSxDQUFDLE1BQU07UUFDYjtNQUNGLENBQUM7TUFDREMsV0FBVyxFQUFFO0lBQ2YsQ0FBQyxDQUFDOztJQUVGO0lBQ0EsTUFBTUMsTUFBTSxHQUFHbEIsSUFBSSxDQUFDbUIsSUFBSSxDQUFDQyxZQUFZLENBQUMsQ0FBQztJQUN2QyxJQUFBQyxtQkFBWSxFQUNWSCxNQUFNLEVBQ04sSUFBSSxDQUFDdEIsTUFBTSxFQUNYLElBQUksQ0FBQ0UsTUFBTSxDQUFDd0IsTUFBTSxFQUNsQixJQUFJLENBQUN4QixNQUFNLENBQUN5QixjQUFjLEVBQzFCLElBQUksQ0FBQ3pCLE1BQU0sQ0FBQzBCLE9BQ2QsQ0FBQztJQUVELE9BQU8sQ0FBQyxDQUFDO0VBQ1g7RUFFT0MsS0FBS0EsQ0FBQ3pCLElBQWUsRUFBc0I7SUFDaEQsSUFBSSxDQUFDSixNQUFNLENBQUNNLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztJQUN0QyxPQUFPLENBQUMsQ0FBQztFQUNYO0VBRU93QixJQUFJQSxDQUFBLEVBQUc7SUFDWixJQUFJLENBQUM5QixNQUFNLENBQUNNLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztFQUN4QztBQUNGO0FBQUN5QixPQUFBLENBQUFwQyxhQUFBLEdBQUFBLGFBQUEiLCJpZ25vcmVMaXN0IjpbXX0=